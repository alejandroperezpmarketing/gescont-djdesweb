from django.apps import AppConfig


class AppdeswebConfig(AppConfig):
    name = 'appdesweb'
