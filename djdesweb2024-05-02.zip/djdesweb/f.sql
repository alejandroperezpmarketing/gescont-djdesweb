create table demo2(gid serial primary key, descripcion varchar);







